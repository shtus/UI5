sap.ui.jsview("zshipmentdash.Shipment", {
  /** Specifies the Controller belonging to this View.
  * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
  * @memberOf zshipmentdash.Shipment
  */
  getControllerName : function() {
    return "zshipmentdash.Shipment";
  },
  /** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed.
  * Since the Controller is given to this method, its event handlers can be attached right away.
  * @memberOf zshipment_dash.Shipment
  */
  createContent : function(oController) {
    //Start of Application Header Control
    var oAppHeader = new sap.ui.commons.ApplicationHeader(
        "appHeader" ,{
          width : '100%'
        });
      //Set logo and text
    //oAppHeader.setLogoSrc("http://www.fetchlogos.com/wp-content/uploads/2015/12/Chevron-Logo.png");
    oAppHeader.setLogoSrc("images/Chevron-Logo.png");
    oAppHeader.setLogoText("Lubricants Shipping Management");
    //End of Application Header Control
    //Start of Outlook Label
    var outlookLabel = new sap.ui.commons.Label(
        "outlookLabel", {
          width : '100%'
        });
    outlookLabel.setText("3-Day Shipment Exceptions Outlook");
    //End of Outlook
    // horizontal layout -->dropdowns and checkboxes
    //Labels
    // risk level checkbox label
    var oLabel1 = new sap.ui.commons.Label("plantLabel", {
      text : "Plant"
    });
    var riskLabel = new sap.ui.commons.Label("riskLabel", {
      width : '100%'
    });
    riskLabel.setText("Risk Level");
    var criticalLabel = new sap.ui.commons.Label(
        "criticalLabel", {
          text : "High"
        });
    var highLabel = new sap.ui.commons.Label("highLabel", {
      text : "Medium"
    });
  //  var mediumLabel = new sap.ui.commons.Label(
    //    "mediumLabel", {
      //    text : "Medium"
       // });
    var moderateLabel = new sap.ui.commons.Label(
            "moderateLabel", {
              text : "Low"
            });
//    var lowLabel = new sap.ui.commons.Label(
  //          "lowLabel", {
    //          text : "Low"
      //      });
    var issuesLabel = new sap.ui.commons.Label(
         "issuesLabel", {
          text : "Issues"
            });

        var dateLabel = new sap.ui.commons.Label(
         "dateLabel", {
          text : "Report Date"
            });
    //End of Labels
    //Start of dropdown boxes
    //Start of V2 Changes

    var oLoadDate = new sap.ui.commons.DatePicker('LoadDate');
    var oTodaysFormat = sap.ui.core.format.DateFormat.getDateInstance({pattern: "yyyyMMdd"});
    var todaysDate = oTodaysFormat.format(new Date());
        oLoadDate.setYyyymmdd( todaysDate );
        oLoadDate.setLocale("en-US");
        oLoadDate.attachChange(
        function(event){
        oController.changeDate(event);
        });

//End of V2 changes


    // plant dropdown
    var oPlantDropdown = new sap.ui.commons.DropdownBox("plantDropdown",{
              change: function(event){
            oController.setFilter(event); }
    });
    var oItemTemplate1 = new sap.ui.core.ListItem();
    oItemTemplate1.bindProperty('key', 'Werks');
    oItemTemplate1.bindProperty('text', 'Werks');

    oPlantDropdown.bindItems("/data" , oItemTemplate1);
    //End of Plant dropdown

    // issues dropdown

    var oIssuesDropdown = new sap.ui.commons.DropdownBox("issuesDropdown",{
              change: function(event){
            oController.setFilter(event); }
    });
    var oItemTemplate1 = new sap.ui.core.ListItem();
    oItemTemplate1.bindProperty('key', 'IssueCode');
    oItemTemplate1.bindProperty('text', 'ZissueDesc');

    oIssuesDropdown.bindItems("/data" , oItemTemplate1);

  //end of issue dropdown

    // customer label
    var customerLabel = new sap.ui.commons.Label(
        "customerLabel", {
          text : "Customer"
        });
    // customer dropdown
    var oCustomerDropdown = new sap.ui.commons.DropdownBox("customerDropdown",{
              change: function(event){
            oController.setFilter(event); }
    });
    var oItemTemplate1 = new sap.ui.core.ListItem();
    oItemTemplate1.bindProperty('key', 'Kunwe');
    oItemTemplate1.bindProperty('text', 'Kunwe');

    oCustomerDropdown.bindItems("/data" , oItemTemplate1);

    //End of Customer dropdown
    // checkbox
    oController.oCB1 = new sap.ui.commons.CheckBox(
        "criticalCheckbox", {
//          checked : true,
          change : function(event) {
            oController.setFilter(event);
          }
        });
    oController.oCB2 = new sap.ui.commons.CheckBox(
        "highCheckbox", {
//          checked : true,
          change : function(event) {
            oController.setFilter(event);
          }
        });
    oController.oCB4 = new sap.ui.commons.CheckBox(
        "moderateCheckbox", {
//          checked : true,
          change : function(event) {
            oController.setFilter(event);
          }
        });
    // checkbox
    // horizontal layout container
    var oLayout = new sap.ui.layout.HorizontalLayout(
        "Layout1", {
          content : [ dateLabel, oLoadDate, oLabel1, oPlantDropdown,
              riskLabel,oController.oCB1,
              criticalLabel, oController.oCB2,
              highLabel,  oController.oCB4,
              moderateLabel,
              issuesLabel,
              oIssuesDropdown, customerLabel,
              oCustomerDropdown ]
        });

    //End of horizontal layout

    var dialLabel = new sap.ui.commons.TextView(
         "dialLabel", {
          text : "% Orders \n with Issue",
          textAlign : "Center"
            });

    var controls = [];
    oController.oDay1 = new sap.ui.commons.Label("Day1");
    oController.oDay2 = new sap.ui.commons.Label("Day2");
    oController.oDay3 = new sap.ui.commons.Label("Day3");
    oController.oChart1 = new sap.suite.ui.microchart.RadialMicroChart(
        "criticalMicrochart", {
          valueColor : "#FF5900"
        });
    oController.oChart2 = new sap.suite.ui.microchart.RadialMicroChart(
        "highMicrochart", {
          valueColor : "#FF9200"
        });
    oController.oChart3 = new sap.suite.ui.microchart.RadialMicroChart(
            "moderateMicrochart", {
              valueColor : "#f4d742"   //"#FFC900"
            });
    var oChartLayout = new sap.ui.layout.VerticalLayout(
        "chartLayout", {
          width : '40%',
          content : [ dialLabel, oController.oDay1, oController.oChart1,
              oController.oDay2,oController.oChart2,
              oController.oDay3,oController.oChart3,
                ]
        });

    //table
    var oDColumnShip0 = new sap.ui.table.Column("D0", {
      label : 'Risk',
      width : '50px',
      template : new sap.ui.commons.TextView()
          .bindProperty("text", "Zseverity" ,
          function(cellValue){
                    this
                        .removeStyleClass("critical high moderate");
                    if (cellValue == "HIGH" )
                      this
                          .addStyleClass("critical");
                    if (cellValue == "MEDIUM" )
                      this
                          .addStyleClass("high");
                    if (cellValue == "LOW")
                        this
                            .addStyleClass("moderate");
                    return "";
          }).addStyleClass('circle')
    });

    var oDColumnShip1 = new sap.ui.table.Column("D1", {
      label : 'Issue',
      width : '90px',
      template : new sap.ui.commons.TextView()
          .bindProperty("text", "Zseverity" ,
          function(cellValue){
                    this
                        .removeStyleClass("criticalC highC moderateC");
                    if (cellValue == "HIGH" )
                      this
                          .addStyleClass("criticalC");
                    if (cellValue == "MEDIUM" )
                      this
                          .addStyleClass("highC");
                    if (cellValue == "LOW")
                        this
                            .addStyleClass("moderateC");
                    return cellValue;
          })
    });
    var oDColumnShip2 = new sap.ui.table.Column("D2", {
      label : 'Load Date',
      width : '115px',
      template : new sap.ui.commons.TextView()
        .bindProperty("text", {
          parts: [
            {path: "LoadDate"},
            {path: "LoadTime"}
          ],
          formatter: function(LoadDate, LoadTime){

               if (LoadDate && LoadTime) {

                var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({pattern: "dd-MM-yyyy"});
                var oDaten = new Date(LoadDate);

                    LoadTime = LoadTime.replace(/^PT/, '').replace(/S$/, '');
                    LoadTime = LoadTime.replace('H', ':').replace('M', ':');
                    var multipler = 60 * 60;
                    var result = 0;
                    LoadTime.split(':').forEach(function(token) {
                      result += token * multipler;
                      multipler = multipler/ 60;
                    });
                    var timeinmiliseconds = result * 1000;

                var oTimeFormat = sap.ui.core.format.DateFormat.getTimeInstance({pattern: "HH:mm"});
                var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
                var oD = oDateFormat.format(new Date(oDaten.getTime() + TZOffsetMs));
                var oT = oTimeFormat.format(new Date(timeinmiliseconds + TZOffsetMs));

            return oD + " " + oT; }}})
  });
//         .bindProperty("text", "LoadDate" ) });
//       function(cellValue){
  //     var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "dd/MM/yyyy HH:mm "});
    //  return oDateFormat.format(new Date(cellValue));
//return cellValue;
          //})

    var oDColumnShip3 = new sap.ui.table.Column("D3", {
      label : 'Load Status',
      autoResizable: true,
      width : 'auto',
  //    width : '210px',
      template : new sap.ui.commons.TextView()
          .bindProperty("text", "Ltsst")
    });
    var oDColumnShip4 = new sap.ui.table.Column("D4", {
      label : 'Order#',
      width : '80px',

 //V2     template : new sap.ui.commons.TextView()
 //         .bindProperty("text", "Vbeln")

 template: new sap.ui.commons.Link({press:function(event) {
     oController.handlePress(event);
      }}).bindProperty("text", "Vbeln"),

    });
    var oDColumnShip5 = new sap.ui.table.Column("D5", {
      label : 'Type',
      width : '60px',
      template : new sap.ui.commons.TextView()
          .bindProperty("text", "Bsart")
    });
 //   var oDColumnShip6 = new sap.ui.table.Column("D6", {
 //     label : 'Load Type',
 //     template : new sap.ui.commons.TextView()
 //         .bindProperty("text", "ZzloadTyp")
 //   });

    var oDColumnShip7 = new sap.ui.table.Column("D7", {
      width : '100px',
      label : 'MoT',
      template : new sap.ui.commons.TextView()
          .bindProperty("text", "Mot" ,
              function(cellValue){
              if (cellValue == 'J1')
               return cellValue = "Bulk Truck";
              if (cellValue == "J2")
               return cellValue = "Package Truck";
              if (cellValue == "R_")
                return cellValue = "Rail Car";
         })
    });

    var oDColumnShip8 = new sap.ui.table.Column("D8", {
      label : 'Method',
      width : '80px',
      template : new sap.ui.commons.TextView()
          .bindProperty("text", "ZzdelMet")
    });
    var oDColumnShip9 = new sap.ui.table.Column("D9", {
      label : 'Customer',
      width : '90px',
      template : new sap.ui.commons.TextView()
          .bindProperty("text", "Kunwe")
    });

    var oDColumnShip11 = new sap.ui.table.Column("D11", {
      label : 'Name',
      width : '90px',
      template : new sap.ui.commons.TextView()
          .bindProperty("text", "Name1")
    });

    var oDColumnShip10 = new sap.ui.table.Column("D10", {
      label : 'Issue Desc.',
      autoResizable: true,
      width : 'auto',
      template : new sap.ui.commons.TextView()
          .bindProperty("text", "ZissueDesc")
    });
    var oTableShip = new sap.ui.table.Table("shipTable", {
      visibleRowCount : 15
    });

    oTableShip.addColumn(oDColumnShip0);
    oTableShip.addColumn(oDColumnShip1);
    oTableShip.addColumn(oDColumnShip2);
    oTableShip.addColumn(oDColumnShip3);
    oTableShip.addColumn(oDColumnShip4);
    oTableShip.addColumn(oDColumnShip5);
    // oTableShip.addColumn(oDColumnShip6);
    oTableShip.addColumn(oDColumnShip7);
    oTableShip.addColumn(oDColumnShip8);
    oTableShip.addColumn(oDColumnShip9);
    oTableShip.addColumn(oDColumnShip11);
    oTableShip.addColumn(oDColumnShip10);
    oTableShip.setSelectionMode(sap.ui.table.SelectionMode.None);
    //oTableShip.autoResizeColumn(11);

    var x = sap.ui.getCore().byId("shipTable");
    var oImageTest1 = new sap.ui.commons.Image("");
    oImageTest1.setSrc("images/dayoutlook.png");
    var oImageTest2 = new sap.ui.commons.Image("");
    oImageTest2.setSrc("images/ordersbumped.png");
    //var oImageTest3 = new sap.ui.commons.Image("");
   // oImageTest3.setSrc("images/planneddeliveries.png");//
    var oImageTest3 = new sap.m.Image({ src: "images/planneddeliveries.png",
                                        press: function(event)
                                        {oController.handleImage(event); }
                                        });

    var oImageTest4 = new sap.ui.commons.Image("");
    oImageTest4.setSrc("images/plantperformance.png");
    var oDashboard = new sap.ui.layout.VerticalLayout(
        "oDashboard", {
         // width : '20%',
          content : [ oImageTest1, oImageTest2,
              oImageTest3, oImageTest4 ]
        });
    var oHLayoutForTable = new sap.ui.layout.VerticalLayout(
        "oHLayoutForTable", {
//          width : '98%',
          content : [ oTableShip
               ]
        });
    var oHLayoutForAll = new sap.ui.layout.HorizontalLayout(
        "oHLayoutForAll", {
          content : [ oChartLayout, oHLayoutForTable,
              oDashboard ]
        });
    //end of table

//var oScrollContainer
//return new sap.m.Shell({
  //      app: new sap.m.ScrollContainer({
    //        vertical: true,
      //      horizontal : true,
        //    content: [oAppHeader , outlookLabel , oLayout , oHLayoutForAll ]
        //})
    // });

    return new sap.m.App({
    pages : new sap.m.Page({
     enableScrolling: false, showHeader : false,         //title : "SHIPMENT DASHBOARD",
       content : [ oAppHeader , outlookLabel , oLayout , oHLayoutForAll ]
       })
       });
  }
});