sap.ui.controller("zshipmentdash.Shipment", {
/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zshipmentdash.Shipment
*/
  onInit: function() {
  //oData Model instantiation
    this.criticalFilter = function(item) {
    return (item["Zseverity"] == "HIGH");
    };
    this.highFilter = function(item) {
    return (item["Zseverity"] == "MEDIUM");
    };
    this.moderateFilter = function(item) {
    return (item["Zseverity"] == "LOW");
    };
//get date
    var nDate = sap.ui.core.format.DateFormat.getDateInstance({pattern: "yyyy-MM-dd"});
    var oDaten = new Date();
    var oDatef = nDate.format(new Date(oDaten));
    var oDateout =   oDatef + 'T00:00:00';
    var oModel = new sap.ui.model.odata.ODataModel(
        "/sap/opu/odata/SAP/ZSHIPMENT_DASHBOARD_SRV", true);
    var oArray ;
    oModel.read("/ExIssueTableSet",
                     null, ["$filter=LoadDate eq datetime'" +oDateout+ "'" ], false, function(oData, oResponse){
                      oArray = oData;
                    });
    if (typeof( oArray ) === "undefined")
        {
       // {	sap.ui.commons.MessageBox.alert("No data found!");}
        //refresh table data
            var oModelShipping = new sap.ui.model.json.JSONModel();
    oModelShipping.setData({
      modelData : oArray1
        });
    var oTableShip = sap.ui.getCore().byId("shipTable");
    oTableShip.setModel(oModelShipping);
    oTableShip.bindRows("/modelData");
        //end of table refresh
        //refresh dropdowns
    var oModelIssue = new sap.ui.model.json.JSONModel();
    oModelIssue.setData({data: b});
    var oisuedd = sap.ui.getCore().byId("issuesDropdown");
    oisuedd.setModel(oModelIssue);
        //end of issue dropdown
    var oModelPlant = new sap.ui.model.json.JSONModel();
    oModelPlant.setData({data: d});
    var oPlntdd = sap.ui.getCore().byId("plantDropdown");
    oPlntdd.setModel(oModelPlant);
       //end of plant dropdown
    var oModelCust = new sap.ui.model.json.JSONModel();
    oModelCust.setData({data: f});
    var oCustdd = sap.ui.getCore().byId("customerDropdown");
    oCustdd.setModel(oModelCust);
       //end of customer dropdown
this.oDay1
  .setText(oD1);
this.oDay2
  .setText(oD2);
this.oDay3
  .setText(oD3);
//end of drop downs
//charts
this.oChart1
  .setPercentage(0);
this.oChart2
  .setPercentage(0);
this.oChart3
  .setPercentage(0);
//end of charts

        }
    else {
    var oArray1 = oArray.results;
    var oModelShipping = new sap.ui.model.json.JSONModel();
    oModelShipping.setData({
      modelData : oArray1
        });
    var oTableShip = sap.ui.getCore().byId("shipTable");
    oTableShip.setModel(oModelShipping);
    oTableShip.bindRows("/modelData");
   //End of oData
// prepare drop downs
  //issues drop down
    var a = [];
    var b = [];
    a.push("ALL");
    for(var i=0; i<oArray.results.length; i++) {
      if(a.indexOf(oArray.results[i].IssueCode) === -1) {
        a.push(oArray.results[i].IssueCode , oArray.results[i].ZissueDesc );
      }
    }
    for(var j=0; j<a.length; j++) {
      var object = {};
      object.IssueCode = a[j];
      if ( j!=0 ) {
      j = j + 1;
      object.ZissueDesc = a[j] ; }
      else {
      object.ZissueDesc = a[j]; }
      b.push(object);
    }
    var oModelIssue = new sap.ui.model.json.JSONModel();
    oModelIssue.setData({data: b});
    var oisuedd = sap.ui.getCore().byId("issuesDropdown");
    oisuedd.setModel(oModelIssue);
  //plant dropdown
    var c = [];
    var d = [];
    c.push("ALL");
    for(var i=0; i<oArray.results.length; i++) {
      if(c.indexOf(oArray.results[i].Werks) === -1) {
        c.push(oArray.results[i].Werks);
      }
    }
    for(var j=0; j<c.length; j++) {
      var object = {};
      object.Werks = c[j];
      d.push(object);
    }
    var oModelPlant = new sap.ui.model.json.JSONModel();
    oModelPlant.setData({data: d});
    var oPlntdd = sap.ui.getCore().byId("plantDropdown");
    oPlntdd.setModel(oModelPlant);
    //Customer dropdown
    var e = [];
    var f = [];
    e.push("ALL");
    for(var i=0; i<oArray.results.length; i++) {
      if(e.indexOf(oArray.results[i].Kunwe) === -1) {
        e.push(oArray.results[i].Kunwe);
      }
    }
    for(var j=0; j<e.length; j++) {
      var object = {};
      object.Kunwe = e[j];
      f.push(object);
    }
    var oModelCust = new sap.ui.model.json.JSONModel();
    oModelCust.setData({data: f});
    var oCustdd = sap.ui.getCore().byId("customerDropdown");
    oCustdd.setModel(oModelCust);
//labels for date
    var g = [];
    var oDatelow;
    for(var i=0; i<oArray.results.length; i++) {
      if(g.indexOf(oArray.results[i].LoadDate) === -1) {
        g.push(oArray.results[i].LoadDate);
        if ( i == 0 )
        oDatelow = oArray.results[i].LoadDate;
      }
    }
    g.sort();
  var oDay1 = sap.ui.core.format.DateFormat.getDateInstance({pattern: "dd-MM-yyyy"}); //E-M/d
  var oD = new Date(g[0]);
  var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
  var oD1 = oDay1.format(new Date(oD.getTime() + TZOffsetMs));
this.oDay1
  .setText(oD1);
    var oDay2  = new Date(g[1]);
    var oD2   = oDay1.format(new Date(oDay2.getTime() + TZOffsetMs));
this.oDay2
  .setText(oD2);
    var oDay3  = new Date(g[2]);
    var oD3   = oDay1.format(new Date(oDay3.getTime() + TZOffsetMs));
this.oDay3
  .setText(oD3);
//end of drop downs
//charts
this.oChart1
  .setPercentage(Math
    .round((oArray.results
     .filter(this.criticalFilter).length / oArray.results.length) * 100));
this.oChart2
  .setPercentage(Math
    .round((oArray.results
     .filter(this.highFilter).length / oArray.results.length) * 100));
this.oChart3
  .setPercentage(Math
    .round((oArray.results
     .filter(this.moderateFilter).length / oArray.results.length) * 100));
//end of charts
}
},
  setFilter : function() {
    var aFilter = [];
    if (this.oCB1.getChecked())
      aFilter.push(new sap.ui.model.Filter(
          "Zseverity",
          sap.ui.model.FilterOperator.EQ, "HIGH"));
    if (this.oCB2.getChecked())
      aFilter.push(new sap.ui.model.Filter(
          "Zseverity",
          sap.ui.model.FilterOperator.EQ, "MEDIUM" ));
    if (this.oCB4.getChecked())
        aFilter.push(new sap.ui.model.Filter(
            "Zseverity",
            sap.ui.model.FilterOperator.EQ, "LOW" ));
   var oDp = sap.ui.getCore().byId("plantDropdown");
   var sValue = oDp.getSelectedKey();
        if (sValue != "ALL")
        aFilter.push(new sap.ui.model.Filter(
        "Werks",
        sap.ui.model.FilterOperator.EQ, sValue
        ));
   var oDi = sap.ui.getCore().byId("issuesDropdown");
   var sValue = oDi.getSelectedKey();
        if (sValue != "ALL")
        aFilter.push(new sap.ui.model.Filter(
        "IssueCode",
        sap.ui.model.FilterOperator.EQ, sValue
        ));
   var oDc = sap.ui.getCore().byId("customerDropdown");
   var sValue = oDc.getSelectedKey();
        if (sValue != "ALL")
        aFilter.push(new sap.ui.model.Filter(
        "Kunwe",
        sap.ui.model.FilterOperator.EQ, sValue
        ));
     var oTableShip = sap.ui.getCore().byId("shipTable");
     oTableShip.bindRows("/modelData", null, null, aFilter);
  },
  handlePress: function(event) {
  //get selected item
  var oItemobj = event.getSource().getBindingContext().getObject();
//get load number
  var oLoad = oItemobj.Loadno;
    var oCon = "zzloadno=" + oLoad + "#" ;
    var oSource = '/sap/bc/webdynpro/sap/zvd_wd_ord_conf_direct?'
                  + oCon ;
 //   window.open(oSource, '_blank');
    var oFrame = new sap.ui.core.HTML( );
    oFrame.setContent("<iframe src=" + oSource + " width='100%' height='500px'></iframe>");
    var oDialog = new sap.ui.commons.Dialog( {
    width: '80%',
    hight: '500px'
    });
    oDialog.setTitle("View Sales Order");
    oDialog.addContent(oFrame);
    oDialog.setModal(true);
    oDialog.open();
  },
  handleImage : function(event) {
    var oDate = new sap.ui.getCore().byId("LoadDate").getValue();
    var nDate = sap.ui.core.format.DateFormat.getDateInstance({pattern: "yyyy-MM-dd"});
    var oDatef = nDate.format(new Date(oDate));
    var oDateout =   oDatef + 'T00:00:00';
    var oArrayImage ;
    var oModelImage = new sap.ui.model.odata.ODataModel(
          "/sap/opu/odata/SAP/ZSHIPMENT_DASHBOARD_SRV");
        oModelImage.read("/ex_lmetricsSet",
               null, ["$filter=LoadDate eq datetime'" +oDateout+ "'" ] , false, function(oData, oResponse){
               oArrayImage = oData;
               });
        if ( oArrayImage.results.length == 0 )
        {	sap.ui.commons.MessageBox.alert("No data found!");}
        else {
          var d1 = []; var d2 = []; var d3 = []; var d4 = []; var e = [] ; var f = [];
          for(var i=0; i<oArrayImage.results.length; i++) {
              e.push([oArrayImage.results[i].Zday , oArrayImage.results[i].TotalLoads
                    , oArrayImage.results[i].TotalIssues ]);
                d1.push(oArrayImage.results[i].Zday);
                d2.push(oArrayImage.results[i].TotalLoads);
                d3.push(oArrayImage.results[i].TotalIssues);
          }
          for(var j=0; j<e.length; j++) {
            var object = {};
            object.Zday = d1[j];
            object.TotalLoads = d2[j];
            object.TotalIssues = d3[j];
            f.push(object);
          }
          var oModelIbar = new sap.ui.model.json.JSONModel();
          oModelIbar.setData({data: f});
// A Dataset defines how the model data is mapped to the chart
  var oDataset = new sap.viz.ui5.data.FlattenedDataset({
    // a Bar Chart requires exactly one dimension (x-axis)
    dimensions : [
      {
        axis : 1, // must be one for the x-axis, 2 for y-axis
        name : 'Days',
        value : "{Zday}"
      }
    ],
    // it can show multiple measures, each results in a new set of bars in a new color
    measures : [
        // measure 1
      {
        name : 'Loads',
        value : '{TotalLoads}'
      },
      {
        name : 'Issues',
        value : '{TotalIssues}'
      }
    ],
    // 'data' is used to bind the whole data collection that is to be displayed in the chart
    data : {
      path : "/data"
    }
  });
    var oChartBar = new sap.viz.ui5.controls.VizFrame({
    width: '700px',
    dataset : oDataset
  });
    oChartBar.setModel(oModelIbar);
    oChartBar.setVizType('column');
    oChartBar.setVizProperties({
            plotArea: {
                    colorPalette : ['#00cc00','#00ffff']
                   },
            title: {
                    text: "Plant Performance" ,
                    style:{
                    color: '#0033cc',
                    fontFamily:  "Courier New, cursive",
                    fontSize: "20px"
                    }
                    },
            categoryAxis: { label : { style :{
                   color: '#0033cc',
                   fontFamily:  "Courier New, cursive",
                   fontSize: "15px" }},
                   title : { text: "Days" , style :{
                   color: '#0033cc',
                   fontFamily:  "Courier New, cursive",
                   fontSize: "20px"
                   }}},
            valueAxis: { label : { style :{
                   color: '#0033cc',
                   fontFamily:  "Courier New, cursive",
                   fontSize: "15px" }},
                   title : { text: "Loads" , style :{
                   color: '#0033cc',
                   fontFamily:  "Courier New, cursive",
                   fontSize: "20px"
                   }}}
                   });

    var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
          'uid': "valueAxis",
          'type': "Measure",
          'values': ["Loads" , "Issues"]
        }),
        feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
          'uid': "categoryAxis",
          'type': "Dimension",
          'values': ["Days"]
        });
    oChartBar.addFeed(feedValueAxis);
    oChartBar.addFeed(feedCategoryAxis);
//chart control end
//display chart in pop-up
 var oDialog = new sap.m.Dialog({
    width: '60%',
    hight: '400px'
    });
    oDialog.setTitle("7-Days Analysis", { style :{
                   color: '#0033cc',
                   fontFamily:  "Courier New, cursive",
                   fontSize: "20px"
                   }});
    oDialog.addContent(oChartBar);
    oButton = new sap.m.Button ({ text : "Close" ,
                                           press : function (){
                                                   oDialog.close()}
                                                   });
    oDialog.addButton(oButton);
//oDialog.setModal(true);
    oDialog.open();
}
        },
  changeDate : function (event){
        if(event.getParameter("invalidValue"))
          {
          event.oSource.setValueState(sap.ui.core.ValueState.Error);
          }else{
//get date and read oData
          event.oSource.setValueState(sap.ui.core.ValueState.None)
           var sValue = event.getParameter("newValue");
           var oDaten = new Date(sValue);
           var nDate = sap.ui.core.format.DateFormat.getDateInstance({pattern: "yyyy-MM-dd"});
           var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
           var oDatef = nDate.format(new Date(oDaten.getTime() + TZOffsetMs));
           var oDateout =   oDatef + 'T00:00:00';
//refresh bindings
  //oData Model instantiation
    this.criticalFilter = function(item) {
    return (item["Zseverity"] == "HIGH");
    };
    this.highFilter = function(item) {
    return (item["Zseverity"] == "MEDIUM");
    };
    this.moderateFilter = function(item) {
    return (item["Zseverity"] == "LOW");
    };
//start of checkboxes
this.oCB1.setChecked(false);
this.oCB2.setChecked(false);
this.oCB4.setChecked(false);
//end of checkboxes
//get date
    var oModel = new sap.ui.model.odata.ODataModel(
       "/sap/opu/odata/SAP/ZSHIPMENT_DASHBOARD_SRV");
    var oArray ;
    oModel.read("/ExIssueTableSet",
                     null, ["$filter=LoadDate eq datetime'" +oDateout+ "'" ], false, function(oData, oResponse){
                      oArray = oData;
                    });
//7-days data for graph
    var oArrayBar ;
    var oModel = new sap.ui.model.odata.ODataModel(
      "/sap/opu/odata/SAP/ZSHIPMENT_DASHBOARD_SRV");
        oModel.read("/ex_lmetricsSet",
               null, ["$filter=LoadDate eq datetime'" +oDateout+ "'" ] , false, function(oData, oResponse){
               oArrayBar = oData;
               });
      var oModelBar = new sap.ui.model.json.JSONModel();
          oModelBar.setData({
          modelData : oArrayBar
          });
//end of 7days data
        if (typeof( oArray ) === "undefined")
        {
        {	sap.ui.commons.MessageBox.alert("No data found!");}
        //refresh table data
            var oModelShipping = new sap.ui.model.json.JSONModel();
    oModelShipping.setData({
      modelData : oArray1
        });
    var oTableShip = sap.ui.getCore().byId("shipTable");
    oTableShip.setModel(oModelShipping);
    oTableShip.bindRows("/modelData");
        //end of table refresh
        //refresh dropdowns
    var oModelIssue = new sap.ui.model.json.JSONModel();
    oModelIssue.setData({data: b});
    var oisuedd = sap.ui.getCore().byId("issuesDropdown");
    oisuedd.setModel(oModelIssue);
        //end of issue dropdown
    var oModelPlant = new sap.ui.model.json.JSONModel();
    oModelPlant.setData({data: d});
    var oPlntdd = sap.ui.getCore().byId("plantDropdown");
    oPlntdd.setModel(oModelPlant);
       //end of plant dropdown
    var oModelCust = new sap.ui.model.json.JSONModel();
    oModelCust.setData({data: f});
    var oCustdd = sap.ui.getCore().byId("customerDropdown");
    oCustdd.setModel(oModelCust);
       //end of customer dropdown
this.oDay1
  .setText(oD1);
this.oDay2
  .setText(oD2);
this.oDay3
  .setText(oD3);
//end of drop downs
//charts
this.oChart1
  .setPercentage(0);
this.oChart2
  .setPercentage(0);
this.oChart3
  .setPercentage(0);
//end of charts
        }
        else {
    var oArray1 = oArray.results;
    var oModelShipping = new sap.ui.model.json.JSONModel();
    oModelShipping.setData({
      modelData : oArray1
        });
    var oTableShip = sap.ui.getCore().byId("shipTable");
    oTableShip.setModel(oModelShipping);
    oTableShip.bindRows("/modelData");
   //End of oData
// prepare drop downs
  //issues drop down
    var a = [];
    var b = [];
    a.push("ALL");
    for(var i=0; i<oArray.results.length; i++) {
      if(a.indexOf(oArray.results[i].IssueCode) === -1) {
        a.push(oArray.results[i].IssueCode , oArray.results[i].ZissueDesc );
      }
    }
    for(var j=0; j<a.length; j++) {
      var object = {};
      object.IssueCode = a[j];
      if ( j!=0 ) {
      j = j + 1;
      object.ZissueDesc = a[j] ; }
      else {
      object.ZissueDesc = a[j]; }
      b.push(object);
    }
    var oModelIssue = new sap.ui.model.json.JSONModel();
    oModelIssue.setData({data: b});
    var oisuedd = sap.ui.getCore().byId("issuesDropdown");
    oisuedd.setModel(oModelIssue);
  //plant dropdown
    var c = [];
    var d = [];
    c.push("ALL");
    for(var i=0; i<oArray.results.length; i++) {
      if(c.indexOf(oArray.results[i].Werks) === -1) {
        c.push(oArray.results[i].Werks);
      }
    }
    for(var j=0; j<c.length; j++) {
      var object = {};
      object.Werks = c[j];
      d.push(object);
    }
    var oModelPlant = new sap.ui.model.json.JSONModel();
    oModelPlant.setData({data: d});
    var oPlntdd = sap.ui.getCore().byId("plantDropdown");
    oPlntdd.setModel(oModelPlant);
    //Customer dropdown
    var e = [];
    var f = [];
    e.push("ALL");
    for(var i=0; i<oArray.results.length; i++) {
      if(e.indexOf(oArray.results[i].Kunwe) === -1) {
        e.push(oArray.results[i].Kunwe);
      }
    }
    for(var j=0; j<e.length; j++) {
      var object = {};
      object.Kunwe = e[j];
      f.push(object);
    }
    var oModelCust = new sap.ui.model.json.JSONModel();
    oModelCust.setData({data: f});
    var oCustdd = sap.ui.getCore().byId("customerDropdown");
    oCustdd.setModel(oModelCust);
//labels for date
    var g = [];
    var oDatelow;
    for(var i=0; i<oArray.results.length; i++) {
      if(g.indexOf(oArray.results[i].LoadDate) === -1) {
        g.push(oArray.results[i].LoadDate);
        if ( i == 0 )
        oDatelow = oArray.results[i].LoadDate;
      }
    }
    g.sort();
  var oDay1 = sap.ui.core.format.DateFormat.getDateInstance({pattern: "dd-MM-yyyy"});
  var oD = new Date(g[0]);
  var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
  var oD1 = oDay1.format(new Date(oD.getTime() + TZOffsetMs));
this.oDay1
  .setText(oD1);
    var oDay2  = new Date(g[1]);
    var oD2   = oDay1.format(new Date(oDay2.getTime() + TZOffsetMs));
this.oDay2
  .setText(oD2);
    var oDay3  = new Date(g[2]);
    var oD3   = oDay1.format(new Date(oDay3.getTime() + TZOffsetMs));
this.oDay3
  .setText(oD3);
//end of drop downs
//charts
this.oChart1
  .setPercentage(Math
    .round((oArray.results
     .filter(this.criticalFilter).length / oArray.results.length) * 100));
this.oChart2
  .setPercentage(Math
    .round((oArray.results
     .filter(this.highFilter).length / oArray.results.length) * 100));
this.oChart3
  .setPercentage(Math
    .round((oArray.results
     .filter(this.moderateFilter).length / oArray.results.length) * 100));
//end of charts
//end refresh bindings
} //end of else
          }
  }
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zshipmentdash.Shipment
*/
//  onBeforeRendering: function() {
//
//  },
/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zshipmentdash.Shipment
*/
  //onAfterRendering: function() {
//  }
/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zshipmentdash.Shipment
*/
//  onExit: function() {
//
//  }
});